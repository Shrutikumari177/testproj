sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (Controller) => {
  "use strict";

  return Controller.extend("masterdata.controller.VoyageDashboard", {
      onInit() {
      }
  });
});